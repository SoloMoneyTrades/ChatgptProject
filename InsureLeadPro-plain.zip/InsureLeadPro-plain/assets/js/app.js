(function () {
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));
  $("#year").textContent = new Date().getFullYear().toString();
  const DB_KEY = "insurelead_pro_db_v1";
  const defaultData = {
    leads: [
      { id: uid(), name: "John Smith", premium: 500, stage: "NEW" },
      { id: uid(), name: "Jane Doe", premium: 800, stage: "CONTACTED" },
      { id: uid(), name: "Mike Johnson", premium: 1200, stage: "PROPOSAL" }
    ],
    agents: [
      { id: uid(), name: "Ava Agent", email: "ava@example.com" },
      { id: uid(), name: "Noah Agent", email: "noah@example.com" }
    ],
    chat: []
  };
  function uid(){ return Math.random().toString(36).slice(2,10); }
  function load(){
    try{ const raw = localStorage.getItem(DB_KEY); return raw? JSON.parse(raw): defaultData; }
    catch(e){ return defaultData; }
  }
  let state = load();
  function save(){ localStorage.setItem(DB_KEY, JSON.stringify(state)); render(); }

  // Navigation
  $$(".nav-btn").forEach(btn => btn.addEventListener("click", ()=>showSection(btn.dataset.target)));
  function showSection(id){ $$(".section").forEach(s=>s.classList.remove("active")); $("#"+id).classList.add("active"); }

  // Quick add
  $("#qaAdd").addEventListener("click", ()=>{
    const name = $("#qaName").value.trim();
    const premium = Number($("#qaPremium").value||0);
    if(!name) return alert("Enter a name");
    state.leads.push({id:uid(), name, premium, stage:"NEW"});
    $("#qaName").value=""; $("#qaPremium").value="";
    save(); showSection("pipeline");
  });

  // FAB
  $("#fab").addEventListener("click", ()=>{
    const name = prompt("Lead name?"); if(!name) return;
    const premium = Number(prompt("Premium (USD)?")||0);
    state.leads.push({id:uid(), name, premium, stage:"NEW"}); save(); showSection("pipeline");
  });

  // Pipeline
  const STAGES=["NEW","CONTACTED","PROPOSAL","CLOSED"];
  $("#addLeadBtn").addEventListener("click", ()=>{
    const name = prompt("Lead name?"); if(!name) return;
    const premium = Number(prompt("Premium (USD)?")||0);
    state.leads.push({id:uid(), name, premium, stage:"NEW"}); save();
  });
  function renderKanban(){
    STAGES.forEach(stage=>{
      const col = $("#col-"+stage); col.innerHTML="";
      state.leads.filter(l=>l.stage===stage).forEach(lead=>{
        const card = document.createElement("div"); card.className="card lead"; card.draggable=true; card.dataset.id=lead.id;
        card.innerHTML = `<div>
            <div><strong>${lead.name}</strong></div>
            <div class="meta">$${lead.premium} · ${stage}</div>
          </div>
          <div class="row">
            ${stage!=="CLOSED"?`<button class="btn btn-gold btn-next">Next</button>`:""}
            <button class="btn btn-outline btn-del">Del</button>
          </div>`;
        card.addEventListener("dragstart", e=> e.dataTransfer.setData("text/plain", lead.id));
        card.querySelector(".btn-del").addEventListener("click", ()=>{ state.leads = state.leads.filter(l=>l.id!==lead.id); save(); });
        const nextBtn = card.querySelector(".btn-next");
        if(nextBtn){ nextBtn.addEventListener("click", ()=>{ const i=STAGES.indexOf(lead.stage); if(i<STAGES.length-1) lead.stage=STAGES[i+1]; save(); }); }
        col.appendChild(card);
      });
    });
    $$(".column").forEach(col=>{
      const body = col.querySelector(".col-body");
      body.addEventListener("dragover", e=>e.preventDefault());
      body.addEventListener("drop", e=>{ e.preventDefault(); const id=e.dataTransfer.getData("text/plain"); const lead=state.leads.find(l=>l.id===id); if(lead){ lead.stage=col.dataset.stage; save(); } });
    });
  }

  // Agents
  $("#addAgentBtn").addEventListener("click", ()=>{
    const name = prompt("Agent name?"); if(!name) return;
    const email = prompt("Agent email?")||"";
    state.agents.push({ id: uid(), name, email }); save();
  });
  function renderAgents(){
    const list=$("#agentList"); list.innerHTML="";
    state.agents.forEach(a=>{
      const li=document.createElement("li"); li.className="list-item row space-between";
      li.innerHTML=`<div><strong>${a.name}</strong><div class="muted">${a.email}</div></div>
      <button class="btn btn-outline">Remove</button>`;
      li.querySelector("button").addEventListener("click", ()=>{ state.agents=state.agents.filter(x=>x.id!==a.id); save(); });
      list.appendChild(li);
    });
  }

  // Chat
  $("#chatSend").addEventListener("click", sendChat);
  $("#chatInput").addEventListener("keydown", e=>{ if(e.key==="Enter") sendChat(); });
  function sendChat(){
    const input=$("#chatInput"); const text=input.value.trim(); if(!text) return;
    state.chat.push({ id: uid(), text, me: true, at: Date.now()}); input.value=""; save();
  }
  function renderChat(){
    const box=$("#chatBox"); box.innerHTML="";
    state.chat.forEach(m=>{
      const div=document.createElement("div"); div.className="bubble"+(m.me?" me":"");
      const dt=new Date(m.at||Date.now()).toLocaleString();
      div.innerHTML=`<div>${m.text}</div><div class="meta">${dt}</div>`;
      box.appendChild(div);
    });
    box.scrollTop=box.scrollHeight;
  }

  // Export
  $("#exportBtn").addEventListener("click", ()=>{
    const blob = new Blob([JSON.stringify(state,null,2)], {type:"application/json"});
    const url = URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="insurelead-pro-data.json"; a.click(); URL.revokeObjectURL(url);
  });

  function renderStats(){
    const leads = state.leads.length;
    const closed = state.leads.filter(l=>l.stage==="CLOSED").length;
    const premium = state.leads.filter(l=>l.stage==="CLOSED").reduce((s,l)=>s+(Number(l.premium)||0),0);
    const agents = state.agents.length;
    document.getElementById("statTotalLeads").textContent = String(leads);
    document.getElementById("statClosed").textContent = String(closed);
    document.getElementById("statPremium").textContent = "$"+premium;
    document.getElementById("statAgents").textContent = String(agents);
  }

  function render(){ renderKanban(); renderAgents(); renderChat(); renderStats(); }
  render();
})();