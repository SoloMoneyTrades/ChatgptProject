
# InsureLead Pro – Fullstack (Production-Ready Starter)

**Stack**
- Backend: Node.js + Express + Prisma + PostgreSQL + JWT Auth + Socket.IO
- Frontend: React + Vite + TailwindCSS
- DevOps: Docker Compose, .env files, seed script

**Features**
- Auth (login/register) with roles: `owner`, `manager`, `agent`, `recruit`
- Leads pipeline (CRUD) with stages: new → contacted → proposal → closed
- Agents management (CRUD), onboarding checklists
- Training center (modules, lessons, progress), video placeholders
- Team chat (real-time via Socket.IO)
- Simple analytics on dashboard

## Quick start (Docker)
1. Copy `.env.example` to `.env` in project root and in `backend/.env` and `frontend/.env` as needed.
2. Run:
   ```bash
   docker compose up --build
   ```
3. App: http://localhost:5173  
   API: http://localhost:4000  
   PgAdmin (optional if enabled): http://localhost:5050

## Local (no Docker)
- Backend:
  ```bash
  cd backend
  npm i
  npx prisma migrate dev --name init
  npm run seed
  npm run dev
  ```
- Frontend:
  ```bash
  cd frontend
  npm i
  npm run dev
  ```

## Default demo logins (password: `demo123`)
- owner@demo.app, manager@demo.app, agent1@demo.app, agent2@demo.app, recruit@demo.app
