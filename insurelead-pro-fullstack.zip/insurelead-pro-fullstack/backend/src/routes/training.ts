
import { Router } from 'express';
import { prisma } from '../models/db.js';

const router = Router();

router.get('/modules', async (_req, res) => {
  const modules = await prisma.trainingModule.findMany({ include: { lessons: true } });
  res.json(modules);
});

router.post('/modules', async (req, res) => {
  const { title, summary, videoUrl } = req.body;
  const mod = await prisma.trainingModule.create({ data: { title, summary, videoUrl } });
  res.json(mod);
});

router.post('/lessons', async (req, res) => {
  const { moduleId, title, body } = req.body;
  const lesson = await prisma.trainingLesson.create({ data: { moduleId, title, body } });
  res.json(lesson);
});

export default router;
