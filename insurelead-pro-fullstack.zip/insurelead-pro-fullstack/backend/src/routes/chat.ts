
import { Router } from 'express';
import { prisma } from '../models/db.js';

const router = Router();

router.get('/messages', async (_req, res) => {
  const msgs = await prisma.message.findMany({ include: { user: { select: { name: true, email: true } } }, orderBy: { createdAt: 'desc' }, take: 50 });
  res.json(msgs);
});

router.post('/messages', async (req, res) => {
  const { text, userId } = req.body;
  const msg = await prisma.message.create({ data: { text, userId } });
  res.json(msg);
});

export default router;
