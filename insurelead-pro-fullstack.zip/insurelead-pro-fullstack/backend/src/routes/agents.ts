
import { Router } from 'express';
import { prisma } from '../models/db.js';

const router = Router();

router.get('/', async (_req, res) => {
  const agents = await prisma.user.findMany({ where: { role: { in: ['OWNER','MANAGER','AGENT','RECRUIT'] } }, select: { id:true, name:true, email:true, role:true } });
  res.json(agents);
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const agent = await prisma.user.update({ where: { id }, data: req.body });
  res.json(agent);
});

export default router;
