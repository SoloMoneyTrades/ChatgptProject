
import { Router } from 'express';
import { prisma } from '../models/db.js';

const router = Router();

router.get('/', async (_req, res) => {
  const leads = await prisma.lead.findMany({ orderBy: { createdAt: 'desc' } });
  res.json(leads);
});

router.post('/', async (req, res) => {
  const { name, email, phone, premium, stage, ownerId } = req.body;
  const lead = await prisma.lead.create({ data: { name, email, phone, premium, stage, ownerId } });
  res.json(lead);
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const lead = await prisma.lead.update({ where: { id }, data: req.body });
  res.json(lead);
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  await prisma.lead.delete({ where: { id } });
  res.json({ ok: true });
});

export default router;
