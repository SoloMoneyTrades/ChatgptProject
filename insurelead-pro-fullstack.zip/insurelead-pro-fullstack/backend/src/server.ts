
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import http from 'http';
import { Server } from 'socket.io';
import authRouter from './routes/auth.js';
import leadsRouter from './routes/leads.js';
import agentsRouter from './routes/agents.js';
import trainingRouter from './routes/training.js';
import chatRouter from './routes/chat.js';
import { authMiddleware } from './middlewares/auth.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173', credentials: true }));
app.use(express.json());
app.use(morgan('dev'));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/auth', authRouter);
app.use('/training', authMiddleware, trainingRouter);
app.use('/leads', authMiddleware, leadsRouter);
app.use('/agents', authMiddleware, agentsRouter);
app.use('/chat', authMiddleware, chatRouter);

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' } });

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('chat:send', (payload) => {
    io.emit('chat:message', payload);
  });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log('API listening on ' + PORT));
