
import { prisma } from './models/db.js';
import bcrypt from 'bcryptjs';

async function main() {
  const password = await bcrypt.hash('demo123', 10);
  const users = await prisma.user.createMany({
    data: [
      { email:'owner@demo.app', password, name:'Olivia Owner', role:'OWNER' },
      { email:'manager@demo.app', password, name:'Mason Manager', role:'MANAGER' },
      { email:'agent1@demo.app', password, name:'Ava Agent', role:'AGENT' },
      { email:'agent2@demo.app', password, name:'Noah Agent', role:'AGENT' },
      { email:'recruit@demo.app', password, name:'Riley Recruit', role:'RECRUIT' },
    ],
    skipDuplicates: true
  });

  await prisma.trainingModule.create({
    data: {
      title: 'Needs Analysis',
      summary: 'Discover goals, coverage, and gaps.',
      videoUrl: 'https://samplelib.com/lib/preview/mp4/sample-5s.mp4',
      lessons: { create: [{ title:'Discovery', body:'Use open questions about family, debts, income, goals.' }] }
    }
  });

  await prisma.lead.createMany({
    data: [
      { name:'John Smith', email:'john@example.com', phone:'555-0101', premium:500, stage:'NEW' },
      { name:'Jane Doe', email:'jane@example.com', phone:'555-0102', premium:800, stage:'CONTACTED' },
      { name:'Mike Johnson', email:'mike@example.com', phone:'555-0103', premium:1200, stage:'PROPOSAL' }
    ]
  });

  console.log('Seed complete');
}

main().then(()=>process.exit(0)).catch(e=>{console.error(e);process.exit(1)});
