
import { create } from 'zustand'

type User = { id:string; email:string; name:string; role:string } | null

type State = {
  token: string | null
  user: User
  setAuth: (token:string, user:User) => void
  logout: () => void
}

const useAuth = create<State>((set) => ({
  token: localStorage.getItem('token'),
  user: localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')!) : null,
  setAuth: (token, user) => {
    localStorage.setItem('token', token)
    localStorage.setItem('user', JSON.stringify(user))
    set({ token, user })
  },
  logout: () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    set({ token: null, user: null })
  }
}))

export default useAuth
