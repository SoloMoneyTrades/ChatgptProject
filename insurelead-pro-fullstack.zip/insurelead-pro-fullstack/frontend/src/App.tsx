
import React from 'react'
import { Routes, Route, Navigate, Link } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Pipeline from './pages/Pipeline'
import Training from './pages/Training'
import Agents from './pages/Agents'
import Chat from './pages/Chat'
import Login from './pages/Login'
import Onboarding from './pages/Onboarding'
import useAuth from './store/auth'

function Protected({ children }: { children: JSX.Element }) {
  const { token } = useAuth()
  if (!token) return <Navigate to="/login" replace />
  return children
}

export default function App() {
  return (
    <div className="min-h-screen">
      <nav className="sticky top-0 z-50 bg-black/70 backdrop-blur border-b border-white/10">
        <div className="max-w-6xl mx-auto flex gap-2 p-3 items-center">
          <Link to="/" className="text-gold font-bold">InsureLead Pro</Link>
          <div className="ml-auto flex gap-2">
            <Link to="/" className="btn btn-dark">Dashboard</Link>
            <Link to="/pipeline" className="btn btn-dark">Pipeline</Link>
            <Link to="/training" className="btn btn-dark">Training</Link>
            <Link to="/agents" className="btn btn-dark">Agents</Link>
            <Link to="/chat" className="btn btn-dark">Chat</Link>
          </div>
        </div>
      </nav>
      <Routes>
        <Route path="/login" element={<Login/>} />
        <Route path="/" element={<Protected><Dashboard/></Protected>} />
        <Route path="/pipeline" element={<Protected><Pipeline/></Protected>} />
        <Route path="/training" element={<Protected><Training/></Protected>} />
        <Route path="/agents" element={<Protected><Agents/></Protected>} />
        <Route path="/chat" element={<Protected><Chat/></Protected>} />
        <Route path="/onboarding" element={<Protected><Onboarding/></Protected>} />
      </Routes>
    </div>
  )
}
