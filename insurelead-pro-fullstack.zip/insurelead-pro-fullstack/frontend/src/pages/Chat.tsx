
import React, { useEffect, useState } from 'react'
import api from '../api/client'
import { io } from 'socket.io-client'

const socket = io(import.meta.env.VITE_API_URL || 'http://localhost:4000')

export default function Chat() {
  const [messages, setMessages] = useState<any[]>([])
  const [text, setText] = useState('')

  useEffect(() => {
    api.get('/chat/messages').then(res=>setMessages(res.data.reverse()))
    socket.on('chat:message', (payload:any) => {
      setMessages(prev => [...prev, payload])
    })
    return () => { socket.off('chat:message') }
  }, [])

  const send = async () => {
    if (!text.trim()) return
    const user = JSON.parse(localStorage.getItem('user') || '{}')
    const payload = { text, userId: user.id, user: { name: user.name } }
    setText('')
    socket.emit('chat:send', payload)
    await api.post('/chat/messages', { text, userId: user.id })
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Team Chat</h2>
      <div className="card max-h-96 overflow-y-auto space-y-2">
        {messages.map((m,i)=> (
          <div key={i} className="bg-white/5 rounded p-2">
            <span className="text-gold font-semibold">{m.user?.name || 'Agent'}: </span>
            <span>{m.text}</span>
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-2">
        <input value={text} onChange={e=>setText(e.target.value)} className="flex-grow bg-zinc-900 rounded px-3" placeholder="Type a message..." />
        <button onClick={send} className="btn btn-gold">Send</button>
      </div>
    </div>
  )
}
