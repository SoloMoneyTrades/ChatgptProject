
import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function Training() {
  const [modules, setModules] = useState<any[]>([])
  useEffect(()=>{ api.get('/training/modules').then(res=>setModules(res.data)) },[])

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Training Center</h2>
      <div className="space-y-3">
        {modules.map(m => (
          <details key={m.id} className="card">
            <summary className="cursor-pointer text-gold font-bold">{m.title}</summary>
            <p className="mt-2 opacity-80">{m.summary}</p>
            {m.videoUrl && <video controls className="w-full rounded mt-2" src={m.videoUrl}/>}
            <div className="mt-2 space-y-2">
              {m.lessons.map((l:any)=>(
                <div key={l.id} className="bg-white/5 border border-white/10 rounded p-2">
                  <p className="font-semibold">{l.title}</p>
                  <p className="opacity-80 text-sm">{l.body}</p>
                </div>
              ))}
            </div>
          </details>
        ))}
      </div>
    </div>
  )
}
