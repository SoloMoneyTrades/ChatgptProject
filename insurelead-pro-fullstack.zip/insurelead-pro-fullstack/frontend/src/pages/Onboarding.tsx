
import React from 'react'

export default function Onboarding() {
  const steps = [
    'Upload license & E&O',
    'W-9 and direct deposit',
    'Carrier contracting',
    'CRM login & training module 1',
    'Shadow 2 client calls'
  ]
  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-3">Onboarding Checklist</h2>
      <ul className="space-y-2">
        {steps.map((s,i)=>(
          <li key={i} className="card flex items-center gap-2">
            <input type="checkbox" className="w-5 h-5" />
            <span>{s}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}
