
import React, { useEffect, useState } from 'react'
import api from '../api/client'

const STAGES = ['NEW','CONTACTED','PROPOSAL','CLOSED'] as const

export default function Pipeline() {
  const [leads, setLeads] = useState<any[]>([])
  const load = () => api.get('/leads').then(res=>setLeads(res.data))
  useEffect(() => { load() }, [])

  const nextStage = (lead:any) => {
    const i = STAGES.indexOf(lead.stage)
    if (i < STAGES.length-1) {
      api.put('/leads/'+lead.id, { stage: STAGES[i+1] }).then(load)
    }
  }

  const addLead = () => {
    const name = prompt('Lead name?')
    const premium = Number(prompt('Premium?') || 0)
    if (!name) return
    api.post('/leads', { name, premium, stage:'NEW' }).then(load)
  }

  return (
    <div className="max-w-6xl mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Sales Pipeline</h2>
        <button onClick={addLead} className="btn btn-gold">+ Lead</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {STAGES.map(stage => (
          <div key={stage}>
            <h3 className="font-bold mb-2">{stage}</h3>
            <div className="space-y-2 min-h-[60px]">
              {leads.filter(l=>l.stage===stage).map(l => (
                <div key={l.id} className="card flex justify-between items-center">
                  <span>{l.name} — ${l.premium}</span>
                  {stage!=='CLOSED' && <button onClick={()=>nextStage(l)} className="btn btn-gold">Next</button>}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
