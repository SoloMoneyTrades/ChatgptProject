
import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function Dashboard() {
  const [stats, setStats] = useState({ leads:0, closed:0, premium:0, agents:0 })

  useEffect(() => {
    Promise.all([
      api.get('/leads'),
      api.get('/agents')
    ]).then(([leadsRes, agentsRes]) => {
      const leads = leadsRes.data
      setStats({
        leads: leads.length,
        closed: leads.filter((l:any)=>l.stage==='CLOSED').length,
        premium: leads.filter((l:any)=>l.stage==='CLOSED').reduce((s:number,l:any)=>s+l.premium,0),
        agents: agentsRes.data.length
      })
    })
  }, [])

  return (
    <div className="max-w-6xl mx-auto p-4 grid grid-cols-1 md:grid-cols-4 gap-4">
      <div className="card"><p>Total Leads</p><p className="text-3xl text-gold">{stats.leads}</p></div>
      <div className="card"><p>Closed Sales</p><p className="text-3xl text-gold">{stats.closed}</p></div>
      <div className="card"><p>Premium This Month</p><p className="text-3xl text-gold">${stats.premium}</p></div>
      <div className="card"><p>Active Agents</p><p className="text-3xl text-gold">{stats.agents}</p></div>
    </div>
  )
}
