
import React, { useState } from 'react'
import api from '../api/client'
import useAuth from '../store/auth'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [email, setEmail] = useState('owner@demo.app')
  const [password, setPassword] = useState('demo123')
  const [error, setError] = useState('')
  const { setAuth } = useAuth()
  const nav = useNavigate()

  const submit = async (e:React.FormEvent) => {
    e.preventDefault()
    setError('')
    try {
      const res = await api.post('/auth/login', { email, password })
      setAuth(res.data.token, res.data.user)
      nav('/')
    } catch (e:any) {
      setError(e?.response?.data?.error || 'Login failed')
    }
  }

  return (
    <div className="max-w-md mx-auto p-6 mt-20 card">
      <h1 className="text-2xl font-bold mb-4 text-gold">Login</h1>
      <form onSubmit={submit} className="space-y-3">
        <input className="w-full bg-zinc-900 rounded px-3 py-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input type="password" className="w-full bg-zinc-900 rounded px-3 py-2" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
        {error && <p className="text-red-400">{error}</p>}
        <button className="btn btn-gold w-full">Sign in</button>
      </form>
    </div>
  )
}
